#include "../include/Map.h"
#include "../include/TeachingPlan.h"
#include <iostream>
using namespace std;
int main(void) {
  Plan plan;
  plan.PlanStrategy();
  plan.Display();
  return 0;
}